import cafe from "@/assets/memory-cafe.jpg";
import lavender from "@/assets/memory-lavender-field.jpg";
import picnic from "@/assets/memory-picnic.jpg";
import sunset from "@/assets/memory-sunset.jpg";
import chapterOnePhoto1Asset from "@/assets/chapter-one-photo-1.jpg.asset.json";
import chapterOnePhoto2Asset from "@/assets/chapter-one-photo-2.jpg.asset.json";
import friendshipPhoto1Asset from "@/assets/friendship-photo-1.jpeg.asset.json";
import friendshipPhoto3Asset from "@/assets/friendship-photo-3.jpeg.asset.json";

const friendshipPhoto = friendshipPhoto1Asset.url;
const friendshipPhoto2 = friendshipPhoto3Asset.url;
const chapterOnePhoto1 = chapterOnePhoto1Asset.url;
const chapterOnePhoto2 = chapterOnePhoto2Asset.url;

export type MemoryPhoto = { src: string; alt: string; caption: string; tilt: string };
export type MemoryPage = {
  type: "memory";
  kicker: string;
  title: string;
  date: string;
  photos: [MemoryPhoto, MemoryPhoto];
  notes: [
    { text: string; tone: "lavender" | "cream" | "plum"; rotate: string },
    { text: string; tone: "lavender" | "cream" | "plum"; rotate: string },
    { text: string; tone: "lavender" | "cream" | "plum"; rotate: string },
  ];
};

export const memoryPages: MemoryPage[] = [
  {
    type: "memory",
    kicker: "BEFORE THE LOVE STORY · WE WERE FRIENDS",
    title: "First, you became my favorite person",
    date: "THE FRIENDSHIP THAT STARTED EVERYTHING",
    photos: [
      { src: friendshipPhoto, alt: "A happy friendship memory together", caption: "before we were us", tilt: "-rotate-3" },
      { src: friendshipPhoto2, alt: "A cozy selfie of us together", caption: "my favorite friend", tilt: "rotate-2" },
    ],
    notes: [
      { text: "Before the butterflies and love songs, there was a friendship I never wanted to lose.", tone: "lavender", rotate: "rotate-2" },
      { text: "We laughed, shared everything, and slowly became each other's safest place.", tone: "cream", rotate: "-rotate-2" },
      { text: "Plot twist: my best friend became the love of my life ♡", tone: "plum", rotate: "rotate-1" },
    ],
  },
  {
    type: "memory",
    kicker: "CHAPTER ONE · WHERE IT BEGAN",
    title: "The days that became our story",
    date: "OUR LITTLE FOREVER",
    photos: [
      { src: chapterOnePhoto1, alt: "Us posing together against a wall", caption: "you + me, always", tilt: "-rotate-3" },
      { src: chapterOnePhoto2, alt: "A cozy selfie of us together", caption: "ordinary magic", tilt: "rotate-2" },
    ],
    notes: [
      { text: "Crazyy how we hated each other still ended up being together hehe..", tone: "lavender", rotate: "rotate-2" },
      { text: "I still smile when I remember how easily you made me laugh.", tone: "cream", rotate: "-rotate-2" },
      { text: "P.S. I'd choose you in every lifetime ♡", tone: "plum", rotate: "rotate-1" },
    ],
  },
  {
    type: "memory",
    kicker: "CHAPTER TWO · SOFT MOMENTS",
    title: "A thousand tiny reasons",
    date: "MY FAVORITE PLACE IS BESIDE YOU",
      photos: [
        { src: picnic, alt: "Hands held together at a romantic picnic", caption: "i love u being silly", tilt: "rotate-3" },
        { src: sunset, alt: "A couple watching the sunset at the beach", caption: "MWAAHHH", tilt: "-rotate-2" },
      ],
    notes: [
        { text: "for the moments you made my life feel easier just being in it.", tone: "cream", rotate: "-rotate-1" },
      { text: "You make the smallest moments feel like the ones worth keeping.", tone: "lavender", rotate: "rotate-2" },
      { text: "Dear you: thank you for being my calm and my adventure.", tone: "plum", rotate: "-rotate-2" },
    ],
  },
];

export const giftBoxes = [
  { id: 0, label: "What I adore", icon: "01", image: lavender, note: "Completely in love with your smile, and I promise to never let it fade. From your pretty face to every cute little thing you do, you're my favorite person to admire." },
  { id: 1, label: "Our little things", icon: "02", image: cafe, note: "Coffee dates, sleepy calls, inside jokes — our ordinary things are my treasures." },
  { id: 2, label: "My promise", icon: "03", image: picnic, note: "To keep choosing us, through every season and every version of who we become." },
  { id: 3, label: "Our tomorrow", icon: "04", image: sunset, note: "More sunsets, more adventures, more life — all with you beside me." },
] as const;