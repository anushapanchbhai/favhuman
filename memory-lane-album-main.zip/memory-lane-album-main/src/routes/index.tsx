import { createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Gift, Heart, RotateCcw, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import paperTexture from "@/assets/crumpled-paper.jpg";
import { Button } from "@/components/ui/button";
import { giftBoxes, memoryPages, type MemoryPage } from "@/lib/scrapbook-data";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Our Little Forever — A Love Scrapbook" },
    { name: "description", content: "A romantic, handmade journey through our favorite memories." },
    { property: "og:title", content: "Our Little Forever — A Love Scrapbook" },
    { property: "og:description", content: "A romantic, handmade journey through our favorite memories." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: Scrapbook,
});

const LAST_PAGE = memoryPages.length + 2;

function Scrapbook() {
  const [page, setPage] = useState(0);
  const [direction, setDirection] = useState(1);
  const [openGift, setOpenGift] = useState<number | null>(null);

  const go = (next: number) => {
    setDirection(next > page ? 1 : -1);
    setOpenGift(null);
    setPage(Math.max(0, Math.min(LAST_PAGE, next)));
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight") go(page + 1);
      if (event.key === "ArrowLeft") go(page - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [page]);

  return (
    <main className="relative h-screen min-h-[600px] w-screen overflow-hidden bg-background text-foreground">
      <img src={paperTexture} width={1920} height={1088} alt="" className="absolute inset-0 h-full w-full object-cover opacity-90 mix-blend-multiply" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,color-mix(in_oklab,var(--accent)_22%,transparent),transparent_58%)]" />
      <Decorations page={page} />

      <section key={`${page}-${openGift ?? "closed"}`} className={`page-enter relative z-10 mx-auto h-full max-w-[1720px] ${direction < 0 ? "[animation-direction:reverse]" : ""}`}>
        {page === 0 && <Welcome onOpen={() => go(1)} />}
        {page > 0 && page <= memoryPages.length && <MemoryPageByIndex index={page - 1} />}
        {page === memoryPages.length + 1 && <Gifts openGift={openGift} setOpenGift={setOpenGift} />}
        {page === LAST_PAGE && <Finale onRestart={() => go(0)} />}
      </section>

      {page > 0 && !(page === memoryPages.length + 1 && openGift !== null) && (
        <Button aria-label="Previous page" variant="paper" size="scrapbook" onClick={() => go(page - 1)} className="absolute bottom-7 left-8 z-30"><ArrowLeft /> Back</Button>
      )}
      {page > 0 && page < LAST_PAGE && !(page === memoryPages.length + 1 && openGift !== null) && (
        <Button aria-label="Next page" variant="scrapbook" size="scrapbook" onClick={() => go(page + 1)} className="absolute bottom-7 right-8 z-30">Next <ArrowRight /></Button>
      )}
      <div className="absolute bottom-9 left-1/2 z-20 flex -translate-x-1/2 gap-2" aria-label={`Page ${page + 1} of ${LAST_PAGE + 1}`}>
        {Array.from({ length: LAST_PAGE + 1 }, (_, i) => <span key={i} className={`h-1.5 rounded-full transition-all ${i === page ? "w-8 bg-primary" : "w-1.5 bg-primary/25"}`} />)}
      </div>
    </main>
  );
}

function Welcome({ onOpen }: { onOpen: () => void }) {
  return <div className="flex h-full items-center justify-center px-12 text-center">
    <div className="pop-in relative max-w-5xl">
      <p className="mb-6 text-xs font-semibold tracking-[0.42em] text-primary/70">A LITTLE BOOK OF US · MADE WITH LOVE</p>
      <h1 className="font-display text-[clamp(4rem,8vw,8.5rem)] leading-[.9] text-primary [text-shadow:0_0_45px_color-mix(in_oklab,var(--accent)_70%,transparent)]">Happy Boyfriend&apos;s Day&nbsp;<br />my peeku baby&nbsp;<span className="font-hand text-accent-foreground">♡</span></h1>
      <p className="mx-auto mt-8 max-w-2xl font-hand text-[clamp(1.7rem,2.7vw,3rem)] leading-tight text-foreground/75">For every memory we&apos;ve made, and all the beautiful ones still waiting for us…</p>
      <Button variant="scrapbook" size="scrapbook" className="mt-10" onClick={onOpen}>Open our journey <Sparkles /></Button>
      <p className="mt-5 text-[10px] tracking-[.28em] text-muted-foreground">A LOVE LETTER IN PICTURES</p>
    </div>
  </div>;
}

function Polaroid({ photo, className = "" }: { photo: MemoryPage["photos"][number]; className?: string }) {
  return <figure className={`relative bg-card p-3 pb-12 shadow-[var(--shadow-paper)] ${photo.tilt} ${className}`}>
    <span className="absolute -top-4 left-1/2 z-10 h-9 w-28 -translate-x-1/2 rotate-2 bg-secondary/75 shadow-sm [clip-path:polygon(4%_7%,96%_0,100%_92%,0_100%)]" />
    <img src={photo.src} alt={photo.alt} width={1024} height={1280} loading="lazy" className="h-full w-full object-cover sepia-[.08]" />
    <figcaption className="absolute bottom-2 left-0 w-full text-center font-hand text-2xl text-foreground/80">{photo.caption} ♡</figcaption>
  </figure>;
}

function MemorySpread({ data }: { data: MemoryPage }) {
  return <div className="grid h-full grid-cols-[1.05fr_1.2fr_.85fr] items-center gap-8 px-[7vw] pb-20 pt-16">
    <div className="relative h-[66vh]">
      <Polaroid photo={data.photos[0]} className="absolute left-4 top-4 h-[56vh] w-[22vw] max-w-[360px]" />
      <p className="absolute -bottom-2 left-8 font-hand text-xl text-primary/70">caught in a daydream ✦</p>
    </div>
    <div className="relative flex h-[72vh] flex-col items-center justify-center text-center">
      <span className="text-xs font-semibold tracking-[.3em] text-primary/65">{data.kicker}</span>
      <h2 className="mt-4 max-w-2xl font-display text-[clamp(3rem,5vw,6.2rem)] leading-[.95] text-primary">{data.title}</h2>
      <div className={`mt-8 max-w-lg p-6 shadow-[var(--shadow-paper)] ${data.notes[0].rotate} ${data.notes[0].tone === "cream" ? "bg-card" : "bg-secondary"}`}>
        <p className="font-hand text-[clamp(1.5rem,2.2vw,2.5rem)] leading-tight">{data.notes[0].text}</p>
      </div>
      <p className="mt-7 text-[10px] font-semibold tracking-[.32em] text-muted-foreground">{data.date}</p>
      <div className={`absolute -bottom-2 -left-12 w-64 p-4 shadow-lg ${data.notes[2].rotate} bg-primary text-primary-foreground`}><p className="font-hand text-2xl leading-tight">{data.notes[2].text}</p></div>
    </div>
    <div className="relative h-[70vh]">
      <Polaroid photo={data.photos[1]} className="absolute right-2 top-2 h-[47vh] w-[19vw] max-w-[310px]" />
      <div className={`absolute bottom-0 -left-10 w-[19vw] max-w-[300px] p-5 shadow-[var(--shadow-paper)] ${data.notes[1].rotate} ${data.notes[1].tone === "cream" ? "bg-card" : "bg-secondary"}`}><p className="font-hand text-2xl leading-tight">{data.notes[1].text}</p></div>
    </div>
  </div>;
}

function MemoryPageByIndex({ index }: { index: number }) {
  const memory = memoryPages[index];
  if (!memory) return null;
  return <MemorySpread data={memory} />;
}

function Gifts({ openGift, setOpenGift }: { openGift: number | null; setOpenGift: (id: number | null) => void }) {
  if (openGift !== null) {
    const gift = giftBoxes[openGift];
    if (!gift) return null;
    return <div className="flex h-full flex-col items-center justify-center px-20 pb-20">
      <p className="text-xs font-semibold tracking-[.35em] text-primary/65">A GIFT FROM MY HEART · {gift.icon}</p>
      <h2 className="mt-3 font-display text-6xl text-primary">{gift.label}</h2>
      <div className="mt-8 grid w-full max-w-5xl grid-cols-2 items-center gap-16">
        <Polaroid photo={{ src: gift.image, alt: gift.label, caption: "for keeps", tilt: "-rotate-3" }} className="reveal-left mx-auto h-[50vh] w-[38vh]" />
        <div className="reveal-right rotate-2 bg-secondary p-10 shadow-[var(--shadow-paper)] [animation-delay:180ms]"><Heart className="mb-5 fill-primary/20 text-primary" /><p className="font-hand text-4xl leading-snug">{gift.note}</p><p className="mt-6 text-right font-hand text-2xl text-primary">love, always ♡</p></div>
      </div>
      <Button variant="paper" size="scrapbook" onClick={() => setOpenGift(null)} className="mt-5"><ArrowLeft /> Back to gifts</Button>
    </div>;
  }
  return <div className="flex h-full flex-col items-center justify-center px-16 pb-20 text-center">
    <span className="text-xs font-semibold tracking-[.35em] text-primary/65">FOUR THINGS I SAVED FOR YOU</span>
    <h2 className="mt-3 font-display text-[clamp(3.5rem,6vw,7rem)] text-primary">Little boxes of love</h2>
    <p className="mt-2 font-hand text-3xl text-foreground/65">Pick one. There&apos;s a piece of my heart inside.</p>
    <div className="mt-9 grid w-full max-w-5xl grid-cols-4 gap-7">
      {giftBoxes.map((gift, index) => <button key={gift.id} onClick={() => setOpenGift(gift.id)} style={{ animationDelay: `${index * 100}ms` }} className="gift-rise group relative flex aspect-[.82] cursor-pointer flex-col items-center justify-center overflow-hidden rounded-sm border border-primary/20 bg-secondary/85 shadow-[var(--shadow-paper)] transition duration-300 hover:-translate-y-3 hover:shadow-[var(--shadow-button)]">
        <span className="absolute left-1/2 h-full w-9 -translate-x-1/2 bg-primary/25" /><span className="absolute top-[32%] h-8 w-full bg-primary/25" />
        <Gift className="relative z-10 size-16 text-primary transition-transform group-hover:scale-110" strokeWidth={1.2} />
        <span className="relative z-10 mt-7 bg-card/85 px-3 py-1 font-hand text-2xl text-primary">{gift.label}</span>
        <span className="absolute bottom-3 right-3 font-display text-xl text-primary/40">{gift.icon}</span>
      </button>)}
    </div>
  </div>;
}

function Finale({ onRestart }: { onRestart: () => void }) {
  return <div className="flex h-full items-center justify-center px-16 pb-10 text-center">
    <div className="pop-in relative max-w-5xl">
      <Heart className="mx-auto mb-8 size-16 fill-primary/15 text-primary" strokeWidth={1} />
      <p className="text-xs font-semibold tracking-[.42em] text-primary/65">AND IF YOU EVER WONDER…</p>
      <h2 className="mt-6 font-display text-[clamp(4rem,7vw,8rem)] leading-[.95] text-primary [text-shadow:0_0_55px_color-mix(in_oklab,var(--accent)_75%,transparent)]">I will be loving you<br />for the rest of my life.</h2>
      <p className="mx-auto mt-7 max-w-2xl font-hand text-3xl text-foreground/65">This book has an ending. Us? Never.</p>
      <Button variant="scrapbook" size="scrapbook" onClick={onRestart} className="mt-10"><RotateCcw /> Back to start · review again</Button>
    </div>
  </div>;
}

function Decorations({ page }: { page: number }) {
  return <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-[5] overflow-hidden">
    <span className="twinkle absolute left-[5%] top-[12%] text-3xl text-primary/55">✦</span><span className="twinkle absolute right-[7%] top-[16%] text-2xl text-primary/45 [animation-delay:700ms]">✧</span>
    <span className="absolute left-[3%] top-[46%] -rotate-12 border-2 border-primary/25 px-3 py-1 font-hand text-2xl text-primary/40">love note ♡</span>
    <span className="absolute right-[3%] top-[52%] rotate-12 font-display text-5xl text-primary/30">{String(page + 1).padStart(2, "0")}</span>
    <span className="absolute bottom-[13%] right-[12%] font-hand text-3xl text-primary/35">xoxo</span>
    <span className="absolute left-[16%] top-[7%] text-4xl text-primary/30">୨୧</span>
  </div>;
}