# Scrapbook creator tools

## What will be added
- A creator panel that opens over the scrapbook without changing any page composition.
- A photo library where images can be uploaded, previewed, removed, and assigned to any Polaroid slot.
- Friendship-page fields for notes, date line, photo captions, and decorative labels, with live updates on the page.
- An AI caption action that turns a supplied memory into a short romantic handwritten-style caption.

## Experience
- Keep viewing mode clean and unchanged; editing controls remain hidden until the creator opens the editor.
- Show image thumbnails and clear slot names before assignment.
- Preserve creator changes between visits through Lovable Cloud.
- Include loading, success, empty, and useful error states for uploads and AI writing.

## Technical details
- Enable Lovable Cloud for database records, image storage, and server-side AI access.
- Store uploaded image metadata and scrapbook content separately, with public scrapbook reads and creator-only writes.
- Keep the current data-array page architecture and merge saved overrides onto its defaults.
- Call Lovable AI only from a server function; validate inputs and return safe error messages.
- Verify upload, preview, assignment, editing, AI generation, persistence, and the unchanged 16:9 viewer flow.
