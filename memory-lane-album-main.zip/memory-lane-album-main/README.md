# Memory Lane Album

Build a breathtaking, extraordinary, production-ready horizontal landscape-mode digital scrapbook website designed specifically for laptop screens (16:9 aspect ratio, fixed viewport height, no vertical scrolling on the main view). 

THEME & AESTHETIC:

- Color Palette: A rich, luxurious, and dreamy mix of deep purple accents, soft pastel lavender, and creamy undertones. It should feel deeply romantic, modern, and visually striking.

- Background: A realistic, tactile "scrunched paper" / crumpled vintage paper texture background with soft shadows to give it a physical scrapbook feel.

- Stickers & Details: Floating aesthetic stickers (silver/purple bows, glowing pixel stars, stamped hearts, and textured washi tape holding down every photo).

GLOBAL NAVIGATION & ARCHITECTURE:

- Sleek "Next ➔" and "← Back" navigation buttons on every single page corners.

- IMPORTANT: Structure the code cleanly using data arrays/configs for pages, slides, notes, and images so it is extremely easy to add new pages, more notes, and more pictures later.

PAGE-BY-PAGE STRUCTURE:

1. PAGE 1 (WELCOME & INTRO):

- A mesmerizing, pop-up animated greeting: "Happy Boyfriend's Day 🤍" with a glowing purple/lavender aura.

- Sweet romantic subtitle text and an enchanted "Open Journey ✨" button that smoothly slides to the next experience.

2. PAGE 2 TO X (THE EXTENDED SCRAPBOOK MEMORY LANES):

- Multiple horizontal slides acting as a thick digital scrapbook. 

- EVERY SINGLE PAGE must feature at least one or two Polaroid-style photo frames with realistic tape overlays, paired with *multiple* handwritten-style note cards, sticky notes, and side annotations scattered across the slide.

- Built-in placeholder arrays for dropping in tons of pictures and notes.

3. THE SPECIAL GIFT BOXES PAGE:

- Display 4 glowing, aesthetic purple-lavender gift boxes on screen.

- When clicked, each box opens to reveal a custom sequence of pictures and notes.

- ANIMATION: The pictures and notes must gracefully slide in one-by-one from the left and right sides of the screen with a smooth staggered effect.

- Include a "Back to Gifts" button to explore other boxes.

4. THE FINALE (CLOSING & RESTART):

- A deeply emotional end page with a gorgeous purplish ambient glow, featuring the reminder: "I will be loving you for the rest of my life."

- A prominent "Back to Start / Review Again" button that instantly resets the flow back to Page 1 so he can replay the entire extraordinary experience.

Tech Stack: React, Tailwind CSS, Lucide icons, and butter-smooth slide transitions. Make it look like an award-winning digital experience on a laptop. make sure the entire screen has some intretsing notes and polaraids such  that an image can  be inserted into it

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/e96e90e0-1e43-4e9e-afc7-0dbbf1b4d4cf).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
